"""Preprocessing utilities for genetic clustering experiments."""

import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler


def prepare_features(
    df: pd.DataFrame,
    feature_columns=None,
    scale: bool = True,
) -> pd.DataFrame:
    """Impute numeric features and optionally standardize them."""
    if feature_columns is None:
        feature_columns = df.select_dtypes(include="number").columns.tolist()

    if not feature_columns:
        raise ValueError("No numeric feature columns were found.")

    X = df.loc[:, feature_columns].copy()

    imputer = SimpleImputer(strategy="median")
    X_imputed = imputer.fit_transform(X)

    if scale:
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X_imputed)
        return pd.DataFrame(X_scaled, columns=feature_columns, index=df.index)

    return pd.DataFrame(X_imputed, columns=feature_columns, index=df.index)
