"""Simple research report generation."""

from pathlib import Path
from datetime import date


def generate_markdown_report(
    output_path,
    patient_id="DEMO",
    cluster=None,
    confidence=None,
    model_name="K-means",
):
    """Generate a non-diagnostic research demonstration report."""
    text = f"""# Research Demonstration Report

**Date:** {date.today().isoformat()}  
**Case ID:** {patient_id}  
**Model:** {model_name}  
**Cluster:** {cluster if cluster is not None else "Not available"}  
**Confidence:** {confidence if confidence is not None else "Not available"}

## Important notice

This is a research/educational demonstration only. It is not a clinical
diagnosis and should not be used to guide patient treatment.

## Interpretation

The assigned cluster represents the output of an exploratory machine-learning
workflow. Biological and clinical interpretation requires independent
validation and expert review.
"""
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    return path
