"""Visualization helpers."""

from pathlib import Path
import matplotlib.pyplot as plt


def plot_clusters_2d(
    embedding,
    labels,
    output_path=None,
    title="Cluster visualization",
):
    """Plot a two-dimensional embedding colored by cluster labels."""
    if embedding.shape[1] != 2:
        raise ValueError("Embedding must contain exactly two dimensions.")

    fig, ax = plt.subplots(figsize=(8, 6))
    scatter = ax.scatter(
        embedding[:, 0],
        embedding[:, 1],
        c=labels,
        alpha=0.8,
    )
    ax.set_title(title)
    ax.set_xlabel("Dimension 1")
    ax.set_ylabel("Dimension 2")
    fig.colorbar(scatter, ax=ax, label="Cluster")
    fig.tight_layout()

    if output_path:
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(output_path, dpi=300, bbox_inches="tight")

    return fig, ax
