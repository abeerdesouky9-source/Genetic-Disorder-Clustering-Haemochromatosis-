"""Cluster validation metrics."""

from sklearn.metrics import silhouette_score


def silhouette(X, labels):
    """Return silhouette score when at least two clusters are present."""
    unique = set(labels)
    if len(unique) < 2:
        raise ValueError("Silhouette score requires at least two clusters.")
    return silhouette_score(X, labels)


def cluster_distribution(labels):
    """Return counts for each cluster label."""
    import numpy as np
    values, counts = np.unique(labels, return_counts=True)
    return dict(zip(values.tolist(), counts.tolist()))
