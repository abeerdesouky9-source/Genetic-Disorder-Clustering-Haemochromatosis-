"""Clustering models used in the haemochromatosis prototype."""

from sklearn.cluster import DBSCAN, KMeans


def fit_kmeans(X, n_clusters=6, random_state=42, n_init=20):
    """Fit a K-means model."""
    model = KMeans(
        n_clusters=n_clusters,
        random_state=random_state,
        n_init=n_init,
    )
    model.fit(X)
    return model


def fit_dbscan(X, eps=0.5, min_samples=5):
    """Fit DBSCAN and return the fitted model."""
    model = DBSCAN(eps=eps, min_samples=min_samples)
    model.fit(X)
    return model
