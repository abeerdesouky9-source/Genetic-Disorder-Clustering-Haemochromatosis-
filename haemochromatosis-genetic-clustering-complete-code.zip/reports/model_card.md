# Model Card — Haemochromatosis Clustering Prototype

## Model

K-means clustering prototype for exploratory grouping of genetic features.

## Intended use

Research and educational exploration of genetic clustering.

## Out of scope

- clinical diagnosis
- treatment recommendations
- autonomous patient stratification
- medical decision-making

## Reported performance

The project presentation reports a 0.8298 training silhouette score and a
0.7225 test silhouette score, alongside a reported 89.95% accuracy figure.
These figures should be independently reproduced before being used in any
scientific claim.

## Limitations

- Dataset provenance and composition must be documented.
- Genetic subtype labels may not map cleanly to unsupervised clusters.
- Cluster labels do not inherently represent disease severity.
- External validation is required.
- Clinical deployment requires substantially more validation and governance.

## Ethical considerations

Use only appropriately consented or legally redistributable datasets.
Remove direct identifiers and follow applicable data-protection requirements.
