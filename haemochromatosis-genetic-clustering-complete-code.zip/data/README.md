# Data

Place permitted, de-identified research datasets in this directory.

## Required documentation

For every dataset, record:

- dataset name
- original URL/source
- access date
- version
- license
- preprocessing steps
- relevant feature definitions

The repository intentionally does not include patient-level genetic data.

## Suggested input format

A CSV can contain one row per case and columns representing encoded genetic features.

Example:

```text
sample_id,feature_1,feature_2,feature_3
S001,1,0,2
S002,0,1,1
```

Do not include names, addresses, medical record numbers, or other direct identifiers.
