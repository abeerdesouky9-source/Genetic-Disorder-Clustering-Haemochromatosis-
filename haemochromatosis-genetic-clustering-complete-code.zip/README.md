# Haemochromatosis Genetic Disorder Clustering

An exploratory machine-learning project for clustering and classifying haemochromatosis genetic subtypes using genetic features.

> **Research prototype / educational use only.**  
> This repository is not a clinically validated diagnostic system and must not be used to make medical decisions.

## Project overview

Haemochromatosis is a hereditary metabolic disorder associated with dysregulated iron homeostasis and iron accumulation. This project explores whether unsupervised machine-learning methods can group genetic cases into biologically meaningful clusters.

The project was developed as a research-oriented prototype using:

- Python
- Pandas
- NumPy
- Scikit-learn
- Matplotlib
- K-means clustering
- UMAP dimensionality reduction
- DBSCAN outlier detection
- Silhouette-score validation

The accompanying project presentation describes evidence-based clustering from public genetic datasets and a workflow for mutation-level analysis, clustering, visualization, and report generation.

## Objectives

1. Develop an unsupervised clustering model using patient genetic data.
2. Explore haemochromatosis subtype grouping based on mutations rather than gene names alone.
3. Evaluate cluster quality using quantitative metrics and biological/clinical relevance checks.
4. Provide interpretable visualizations and research reports.
5. Create a foundation that can be extended to other genetic disorders.

## Workflow

```text
Raw genetic data
       |
       v
Data quality control
       |
       v
Feature preprocessing
       |
       +-------------------+
       |                   |
       v                   v
   K-means              DBSCAN
   clustering           outliers
       |
       v
UMAP visualization
       |
       v
Cluster validation
       |
       v
Biological interpretation
       |
       v
Research report
```

## Reported prototype results

The project presentation reports:

| Metric | Reported value |
|---|---:|
| Training silhouette score | 0.8298 |
| Test silhouette score | 0.7225 |
| Train cluster distribution | `[81, 10, 15, 15, 7, 13]` |
| Test cluster distribution | `[41, 7, 6, 0, 6, 1]` |
| Reported model accuracy | 89.95% |

These values are **presentation-reported prototype results**, not independently reproduced clinical performance estimates.

## Repository structure

```text
haemochromatosis-genetic-clustering/
├── README.md
├── LICENSE
├── requirements.txt
├── .gitignore
├── data/
│   ├── README.md
│   ├── raw/
│   └── processed/
├── notebooks/
│   ├── 01_data_preprocessing.ipynb
│   ├── 02_exploratory_analysis.ipynb
│   ├── 03_kmeans_clustering.ipynb
│   ├── 04_umap_visualization.ipynb
│   ├── 05_dbscan_outlier_detection.ipynb
│   └── 06_model_validation.ipynb
├── src/
│   ├── preprocessing.py
│   ├── clustering.py
│   ├── validation.py
│   ├── visualization.py
│   └── reporting.py
├── models/
├── results/
│   └── figures/
├── reports/
└── docs/
```

## Installation

```bash
git clone https://github.com/YOUR-USERNAME/haemochromatosis-genetic-clustering.git
cd haemochromatosis-genetic-clustering

python -m venv .venv

# Windows
.venv\Scripts\activate

# macOS/Linux
source .venv/bin/activate

pip install -r requirements.txt
```

## Example usage

```python
from src.preprocessing import prepare_features
from src.clustering import fit_kmeans
from src.validation import silhouette

X = prepare_features(df)
model = fit_kmeans(X, n_clusters=6)
score = silhouette(X, model.labels_)
print(score)
```

## Data

The presentation identifies Kaggle/public genetic datasets as the dataset source. The actual source dataset and its license should be documented here before redistribution.

Do **not** commit identifiable patient information, clinical records, genetic data with restricted redistribution rights, credentials, or other sensitive information.

## Reproducibility

For reproducible analyses:

- Record dataset version/date.
- Record preprocessing decisions.
- Fix random seeds where appropriate.
- Save model parameters.
- Save evaluation metrics.
- Keep analysis notebooks synchronized with scripts.
- Clearly distinguish exploratory results from validated clinical performance.

## Original analysis code

The complete uploaded notebook is preserved at:

- `notebooks/Copy_of_project.ipynb`
- `legacy/complete_original_code.py`

The Streamlit application extracted from the notebook is:

```bash
streamlit run app.py
```

A simple terminal demonstration is also included:

```bash
python simple_app.py
```

The original notebook contains exploratory iterations and duplicated cells.
For a clean research release, use the modular `src/` implementation and move
dataset-specific logic into a reproducible notebook.

## Future development

Potential extensions include:

- larger and better-curated genetic datasets
- external validation cohorts
- mutation-level biological annotation
- stronger baseline models
- explainable ML
- longitudinal clinical features
- privacy-preserving workflows
- reproducible model cards
- carefully validated clinical decision-support research

## Citation

If you use this repository in academic work, cite the repository and the underlying datasets and publications used by the project.

## Contributors

- Abeer Farag Desouky
- Nour Elhoda Moussa
- Sayeda Abdelrazek Abdelhamid

## Disclaimer

This project is a research/educational prototype. The reported clustering and accuracy results should not be interpreted as evidence of clinical diagnostic accuracy. Any clinical deployment would require appropriate datasets, independent validation, regulatory review, privacy safeguards, and expert clinical oversight.
