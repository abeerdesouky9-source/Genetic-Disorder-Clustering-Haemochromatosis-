# Project Summary

## Scientific motivation

The project investigates whether machine-learning clustering can help organize
haemochromatosis genetic cases into meaningful groups.

## Prototype features

- Genetic entity matching
- Evidence-oriented classification
- Multi-level clustering concept
- Cluster validation
- Visualization
- Research report generation

## Presentation-reported prototype outputs

- K-means clustering
- UMAP dimensionality reduction
- DBSCAN outlier detection
- saved model/validation artifacts
- sample classification cases
- reported 89.95% accuracy

The values above are retained as reported project-presentation outputs and are
not independently verified by this repository scaffold.
