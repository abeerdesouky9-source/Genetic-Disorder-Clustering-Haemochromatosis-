# Methodology

## 1. Data preparation

1. Load an appropriately licensed public/de-identified genetic dataset.
2. Identify numeric genetic features.
3. Handle missing values.
4. Standardize features when appropriate.
5. Preserve a record of all preprocessing decisions.

## 2. Clustering

The prototype uses K-means to identify six exploratory clusters. DBSCAN is
used as an additional outlier-detection approach.

## 3. Dimensionality reduction

UMAP can be used to visualize high-dimensional feature relationships in two
dimensions.

## 4. Validation

Cluster quality can be assessed with silhouette score. Cluster membership
should also be compared cautiously with known genetic subtype information.

## 5. Interpretation

Unsupervised cluster IDs are arbitrary labels. They must not automatically be
interpreted as clinical disease types without biological and clinical evidence.
