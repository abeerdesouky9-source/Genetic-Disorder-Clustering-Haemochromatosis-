"""Small demonstration of the repository workflow."""

import numpy as np
from src.clustering import fit_kmeans
from src.validation import silhouette, cluster_distribution


def main():
    rng = np.random.default_rng(42)
    X = rng.normal(size=(150, 10))

    model = fit_kmeans(X, n_clusters=6)
    score = silhouette(X, model.labels_)

    print("K-means demonstration")
    print("Silhouette score:", round(score, 4))
    print("Cluster distribution:", cluster_distribution(model.labels_))


if __name__ == "__main__":
    main()
