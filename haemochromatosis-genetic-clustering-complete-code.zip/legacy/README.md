# Original project code

`complete_original_code.py` contains the code from every code cell in the
uploaded `Copy_of_project.ipynb`, preserved in notebook-cell order.

`../notebooks/Copy_of_project.ipynb` is the original notebook itself.

Some notebook cells are exploratory, duplicated, Colab-specific, or depend on
files generated in earlier cells. They are preserved here for provenance and
should not be assumed to execute cleanly as one Python script.

The top-level `app.py` and `simple_app.py` are extracted from the original
notebook's Streamlit and command-line demo cells respectively.
